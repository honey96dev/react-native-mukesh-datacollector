export default {
    modalAnimationTiming1: 300,
    modalAnimationTiming2: 500,
    modalAnimationTiming3: 700,
    toastShowTime1: 1500,
    toastShowTime2: 3000,
    toastShowTime3: 5000,
};
