
export const LIST_FORM = 'LIST_FORM';
export const ADD_FORM = 'ADD_FORM';
export const DELETE_FORM = 'DELETE_FORM';
export const EDIT_FORM = 'EDIT_FORM';
export const SET_CREATE_FORM_MODE = 'SET_CREATE_FORM_MODE';