// leave off @2x/@3x
const images = {
  // logo: require('../../assets/images/logo.png'),
  // drawerCover: require('../../assets/images/drawer-cover.jpeg'),
  // avatarRound1: require('../../assets/images/avatar-round-1.png'),
  wave: require('../../assets/images/wave.png'),
  banner: require('../../assets/images/banner.png'),
  logo: require('../../assets/images/logo.png'),
};

export default images
